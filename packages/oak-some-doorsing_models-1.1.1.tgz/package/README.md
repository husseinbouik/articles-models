A reusable and configurable 3D door component for React applications using React Three Fiber.
